import React, {Component} from 'react';
import Orders from './Orders';

class OrderDashboard extends Component {
    constroctor(props) {
        super(props);
        this.state = {
            orders: [],
            selectedOrders: null
        };
    }

    ComponentDidMount() {
    }
    handleOrderSelect = (order) => {
        this.setState({selectedOrder: order});
    }

    render() {
        return {
            <div>
            <h1>Order Dashboard</h1>
            <Orders orders={this.state.orders} onSelect=(this.handleOrderSelect) />
            </div>
        };
    }
}

export default OrderDashboard;